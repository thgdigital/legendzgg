<?php $__env->startComponent('mail::message'); ?>
# Olá <?php echo e($name); ?>

Você está recebendo este e-mail porque recebemos um pedido de redefinição de senha para sua conta.
<?php $__env->startComponent('mail::button', ['url' => $url]); ?>
Redefinir Senha
<?php echo $__env->renderComponent(); ?>
Atenciosamente,<br>
<?php echo e(config('app.name')); ?>

<?php $__env->startComponent('mail::subcopy', ['url' => $url]); ?>
Se você está tendo problemas para clicar no botão de "Redefinir Senha", copie e cole o URL abaixono seu navegador [<?php echo e($url); ?>](<?php echo e($url); ?>)
<?php echo $__env->renderComponent(); ?>
<?php echo $__env->renderComponent(); ?>
