<?php $__env->startSection('content'); ?>

    <?php if(isset($rifas)): ?>
    <?php $__currentLoopData = $rifas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rifa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


        <div class="contant-line">
<?php

                $cor = "";
                echo $rifa->id;

                switch ($rifa->id){
                    case "1":
                        $cor = "azul";
                    case 2:
                        $cor = "verde";
                    case 3:
                        $cor = "amarelo";
                    case 4:
                        $cor = "vermelho";
                }


        ?>
    <?php $__env->startSection('pageTitle',$rifa->name); ?>
            <h5 class="title-rifas shadow-<?php echo $cor; ?>"><?php echo e($rifa->name); ?></h5>
            <div class="line"></div>
            <div class="row">

                <?php $__currentLoopData = $rifa->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php $urlImage = $item->imagem ?>


                    <div class="col-sm-4">
                        <div class="image-rifas border-image border-color-<?php echo $cor; ?>">

                            <a href="/items/<?php echo e($item->slug); ?>">
                                <img src="<?php echo e(asset('assets/imagem/rifas/'.$urlImage)); ?>">

                            </a>
                            <span class="title-img-rifas shadow-<?php echo $cor; ?>">  <?php echo e($item->name); ?></span>
                            <span class="btn valor-rifas">Valor: <small>$
                                   <?php echo number_format($item->valor_rifa, 2, ',', '.')?></small></span>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>