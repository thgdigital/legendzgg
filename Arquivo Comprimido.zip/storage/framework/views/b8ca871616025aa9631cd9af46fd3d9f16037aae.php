<meta charset="utf-8">
<meta name="description" content="">
<meta name="csrf-token" content="<?php echo csrf_token() ?>">
<meta name="author" content="Scotch">
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
<title>Legendzgg - <?php echo $__env->yieldContent('pageTitle'); ?></title>
<link href="<?php echo e(asset('assets/imagem/favicon.ico')); ?>" rel="shortcut icon">
<!-- load bootstrap from a cdn -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.13/css/all.css" integrity="sha384-DNOHZ68U8hZfKXOrtjWvjxusGo9WQnrNx2sqG0tfsghAvtVlRW3tvkXWZh58N9jp" crossorigin="anonymous">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/lightbox.min.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/dataTables.bootstrap.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/style.css')); ?>">
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('assets/css/chat.css')); ?>">
<link rel="stylesheet/scss" type="text/css" href="<?php echo e(asset('assets/scss/_custom-forms.scss')); ?>">
<script src="//cdnjs.cloudflare.com/ajax/libs/sass.js/0.6.3/sass.min.js"></script>