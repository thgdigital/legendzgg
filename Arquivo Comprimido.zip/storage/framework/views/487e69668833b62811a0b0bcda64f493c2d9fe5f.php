<!doctype html>
<html>
<head>
    <?php echo $__env->make('includes.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</head>
<body>


<?php echo $__env->make('includes.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="main">
        <div>
            <?php echo $__env->make('includes.sidebarleft', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
        <div class="container-contenet">
            <?php echo $__env->yieldContent('content'); ?>


        </div>
    </div>
        <?php echo $__env->make('includes.sidebarright', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<input type="text"/>

    <div class="clear">
        <script src="<?php echo e(asset('assets/js/jquery.min.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/jquery.mask.js')); ?>"></script>
        <script src="<?php echo e(asset('assets/js/jquery.validate.js')); ?>"></script>

        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>

        <script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
    </div>
        <?php echo $__env->make('includes.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <?php echo $__env->yieldPushContent('scripts'); ?>


</body>
</html>