<!DOCTYPE html>
<html>
<head>
    <title>E-mail de boas vindas</title>
</head>
<body>
<h2>Bem vindo ao site <?php echo e($user['name']); ?></h2>
<br/>
Seu e-mail registrado é <?php echo e($user['email']); ?> , Por favor, clique no link abaixo para verificar sua conta de e-mail
<br/>
<a href="<?php echo e(url('jogador/verify', $user->verifyUser->token)); ?>">Verificar o e-mail</a>
</body>
</html>
