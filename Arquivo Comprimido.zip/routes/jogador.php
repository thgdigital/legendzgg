<?php
/**
 * Created by PhpStorm.
 * User: thiago
 * Date: 08/07/2018
 * Time: 13:29
 */

Route::group(['middleware' => 'jogador'], function ($router) {
    $router->get('/', [
        'uses' => 'JogadorController@index',
        'as' => 'jogador.index',
    ]);
});
$router->group(['middleware' => ['auth:jogador']], function ($router) {
    $router->get('/', [
        'uses' => 'JogadorController@index',
        'as' => 'jogador.index',
    ]);
});
$router->get('entrar', [
    'uses' => 'AuthController@index',
    'as' => 'jogador.auth.index',
]);
$router->post('', [
    'uses' => 'AuthController@login',
    'as' => 'jogador.auth.login',
]);

$router->get('edit', [
    'uses' => 'JogadorController@edit',
    'as' => 'jogador.edit',
]);
$router->post('cadastro-create', [
    'uses' => 'JogadorController@criarConta',
    'as' => 'jogador.create',
]);
$router->get('verify/{token}', [
    'uses' => 'JogadorController@verifyUser',
    'as' => 'jogador.verify',
]);

$router->post('salvar', [
    'uses' => 'JogadorController@store',
    'as' => 'jogador.salvar',
]);
$router->get('login', [
    'uses' => 'JogadorController@login',
    'as' => 'jogador.login',
]);
$router->get('reset', [
    'uses' => 'JogadorController@reset',
    'as' => 'jogador.reset',
]);

$router->get('email', [
    'uses' => 'JogadorController@email',
    'as' => 'jogador.email',
]);
$router->get('sair', [
    'uses' => 'AuthController@logout',
    'as' => 'jogador.auth.logout',
]);