<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('pages.home');
});
Route::get('/cadastro', function () {
    return view('pages.cadastro');
});
Route::group(['middleware' => ['web']], function ($router) {
    $router->group(['prefix' => 'jogador', 'namespace' => 'Jogador'], function ($router) {
        require app_path('../routes/jogador.php');
    });
});

Route::group(['as'=> 'suporte.' ,'prefix'=> 'suporte', 'middleware' => ['auth:jogador'] ], function() {

    Route::get('', ['as'=> 'index', 'uses'=> 'SuporteController@index']);
    Route::get('create', ['as'=> 'index', 'uses'=> 'SuporteController@create']);

});

Auth::routes();

Route::group(['as'=> 'rifa.' ,'prefix'=> 'rifas' ], function() {

    Route::get('', ['as'=> 'index', 'uses'=> 'RifaController@index']);

    Route::get('{name}', ['as'=> 'categoria', 'uses'=> 'RifaController@categoria']);


});


Route::get('seller_password/reset', 'Jogador\ForgotPasswordController@showLinkRequestForm');
Route::post('seller_password/email', 'Jogador\ForgotPasswordController@sendResetLinkEmail');
Route::get('seller_password/reset/{token}', 'Jogador\ResetPasswordController@showResetForm');
Route::post('seller_password/reset', 'Jogador\ResetPasswordController@reset');

Route::group(['as'=> 'items.' ,'prefix'=> 'items' ], function() {

    Route::get('', ['as'=> 'index', 'uses'=> 'ItemsController@index']);

    Route::get('{name}', ['as'=> 'show', 'uses'=> 'ItemsController@show']);
    Route::post('/lista/{id}', ['as'=> 'show', 'uses'=> 'ItemsController@listaRifas']);
    Route::post('store', ['as'=> 'store', 'uses'=> 'ItemsController@store']);

});

Route::get('/home', 'HomeController@index')->name('home');
