<?php
/**
 * Created by PhpStorm.
 * User: thiago
 * Date: 08/07/2018
 * Time: 13:26
 */
namespace App\Http\Controllers\Jogador;
use App\Mail\VerifyMail;
use App\Models\Jogador;
use App\Models\Saldo;
use App\Models\VerifyJogador;
use Illuminate\Http\Request;
use Illuminate\Contracts\View\View;
use App\Http\Requests;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Storage;
use Validator;
use App\Http\Controllers\Controller;

class JogadorController extends Controller
{
    public function index()
    {
        return view('pages.home');
    }


    public  function criarConta(Request $request){



            $validatedData = Validator::make($request->all(), [
            'name' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:jogadors',
            'senha' => 'required|string|min:6',
            'accet' => 'required',
            'topic' => 'required',
            'nascimento' => 'required',
                'nickName'=>'required|unique:jogadors,username',
        ]);



        if ($validatedData->fails()) {
            return redirect('cadastro')
                ->withErrors($validatedData)
                ->withInput();
        }

        $date = explode("/", $request->input('nascimento'));
        $ano = date('Y');


        $idade = $ano - $date[2];


        if($idade < 18){
            return redirect('cadastro')->with('warning', "Você precisar ser maior de Idade")->withInput();

        }


        $user = Jogador::create([
            'name' => $name = $request->input('name'),
            'email' => $request->input('email'),
            'password' => bcrypt($request->input('senha')),
            'username' => $request->input('nickName'),
            'nascimento' => date('Y-m-d', strtotime($date[2]."-".$date[1]."-".$date[0])),
        ]);

        if($request->hasFile('file') && $request->file('file')->isValid())
        {
            $name =  $user->id.kebab_case($user->name);

            $extension = $request->file('file')->extension();

            $nameFile = "{$name}.{$extension}";

            $upload =  $request->file('file')->storeAs('jogadores', $nameFile, 'public');

            $user->avatar =  $nameFile;



            if(!$upload){
                return redirect()->back()->with('error', 'Falha ao enviar imagem');
            }

            $user->save();
        }

        $saldo = Saldo::create([
            'jogador_id' => $user->id,
            'saldo' => 0,
            'essencia' => 0


        ]);

        $verifyUser = VerifyJogador::create([
            'jogador_id' => $user->id,
            'token' => str_random(40)
        ]);

        Mail::to($user->email)->send(new VerifyMail($user));

        return redirect('jogador/login')->with('warning', "Verifique seu e-mail para ativar sua conta")->withInput();

    }

    public function verifyUser($token)
    {
        $verifyUser = VerifyJogador::where('token', $token)->first();
        if(isset($verifyUser) ){
            $user = $verifyUser->user;
            if(!$user->verified) {
                $verifyUser->user->verified = 1;
                $verifyUser->user->save();
                $status = "Seu e-mail é verdadeiro. Agora você pode fazer o login.";
            }else{
                $status = "Seu e-mail já foi verificado. Agora você pode fazer o login.";
            }
        }else{
            return redirect('cadastro')->with('warning', "Desculpe seu e-mail não pode ser identificado.");
        }

        return redirect('jogador/login')->with('status', $status);
    }

    public function login(){
        return view('pages.login');
    }
    public function reset(){
        return view('pages.reset');
    }
    public function email(){
        return view('pages.email');
    }
    public function edit()
    {


        return view('pages.editPerfil');
    }

    public  function store(Request $request){



        $validatedData = Validator::make($request->all(), [
            'name' => 'required|string|max:255',
            'nascimento' => 'required',

        ]);
        if ($validatedData->fails()) {
            return redirect('jogador/edit')
                ->withErrors($validatedData)
                ->withInput();
        }
        $userId  = Auth::user()->id;
        $user  = Jogador::find($userId);
        $user->name = $request->input('name');

        $date = explode("/", $request->input('nascimento'));
        $ano = date('Y');


        $idade = $ano - $date[2];


        if($idade < 18){
            return redirect('jogador/edit')->with('warning', "Você precisar ser maior de Idade")->withInput();

        }
        $filename = $user->avatar;
        $user->nascimento = date('Y-m-d', strtotime($date[2]."-".$date[1]."-".$date[0]));



        if($request->hasFile('file') && $request->file('file')->isValid())
        {
            unlink(storage_path('app/public/jogadores/'.$filename));

            $name =  $user->id.kebab_case($user->name);

            $extension = $request->file('file')->extension();

            $nameFile = "{$name}.{$extension}";

            $upload =  $request->file('file')->storeAs('jogadores', $nameFile, 'public');

            $user->avatar =  $nameFile;



            if(!$upload){
                return redirect()->back()->with('error', 'Falha ao enviar imagem');
            }

            $user->save();
            return redirect('jogador/edit')->with('success', 'Cadastro atualizado com sucesso');


        }else{
            $user->save();
            return redirect('jogador/edit')->with('success', 'Cadastro atualizado com sucesso');
        }

    }
}
