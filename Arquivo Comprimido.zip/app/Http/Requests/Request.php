<?php
/**
 * Created by PhpStorm.
 * User: thiago
 * Date: 08/07/2018
 * Time: 13:04
 */

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

abstract class Request extends FormRequest
{
    //
}