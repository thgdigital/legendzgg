<?php

namespace App\Models;

use App\Notifications\JogadorResetPasswordNotification;
use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;

class Jogador extends Authenticatable
{
    use Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name', 'email', 'password', 'avatar', 'nascimento', 'username','verified'
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token',
    ];

    public function verifyUser()
    {
        return $this->hasOne('App\Models\VerifyJogador');
    }
    public function saldo()
    {
        return $this->hasOne('App\Models\Saldo');
    }
    public function sendPasswordResetNotification($token)
    {
        $this->notify(new JogadorResetPasswordNotification($token));
    }
}
