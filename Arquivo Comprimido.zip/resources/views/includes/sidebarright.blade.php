<div class="sidebar-right">
    <div class="box-hideen">
        <span class="text-chat">TOTAL ONLINE - 200</span>
        <span class="icon-chat"></span>
    </div>
    <ul class="nav nav-sidebar" id="avatar">
        <li>
            <img src="imagem/avatar.jpg"/>
            <span class="title-avatar">Meu avatar</span>
            <span class="descrition-avatar">This example is a quick exercise </span>
        </li>
        <li>
            <img src="imagem/avatar.jpg"/>
            <span class="title-avatar">Meu avatar</span>
            <span class="descrition-avatar">This example is a quick exercise </span>
        </li>
        <li>
            <img src="imagem/avatar.jpg"/>
            <span class="title-avatar">Meu avatar</span>
            <span class="descrition-avatar">This example is a quick exercise </span>
        </li>
        <li>
            <img src="imagem/avatar.jpg"/>
            <span class="title-avatar">Meu avatar</span>
            <span class="descrition-avatar">This example is a quick exercise </span>
        </li>
        <li>
            <img src="imagem/avatar.jpg"/>
            <span class="title-avatar">Meu avatar</span>
            <span class="descrition-avatar">This example is a quick exercise </span>
        </li>
        <li>
            <img src="imagem/avatar.jpg"/>
            <span class="title-avatar">Meu avatar</span>
            <span class="descrition-avatar">This example is a quick exercise </span>
        </li>
    </ul>
    <div class="chat-footer">
        <div class="login-button">
            <span>
                  To write a message you need to sign in.</span>
        </div>
    </div>
</div>
</div>
<div class="chat" style="bottom: -397px;">
    <div class="chat-show-button">
        <div class="chat-icon"></div>
        <div class="title">Chat</div>
    </div>

</div>
</div>