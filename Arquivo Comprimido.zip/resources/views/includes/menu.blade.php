<ul id="menu-loja">
    <li><a href="#">INVENTÁRIO</a></li>
    <li><a href="#">BAU</a></li>
    <li><a href="#">CARTA</a></li>
    <li><a href="#">BRINDE</a></li>
    <li><a href="#">SAQUE</a></li>

    <li><a href="#" class="active-comprar">COMPRAR CREDITOS</a></li>
</ul>