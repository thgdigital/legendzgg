@extends('layouts.default')


@section('content')

    @isset($rifas)
    @foreach($rifas as $rifa)


        <div class="contant-line">
<?php

                $cor = "";
                echo $rifa->id;

                switch ($rifa->id){
                    case "1":
                        $cor = "azul";
                    case 2:
                        $cor = "verde";
                    case 3:
                        $cor = "amarelo";
                    case 4:
                        $cor = "vermelho";
                }


        ?>
    @section('pageTitle',$rifa->name)
            <h5 class="title-rifas shadow-<?php echo $cor; ?>">{{$rifa->name}}</h5>
            <div class="line"></div>
            <div class="row">

                @foreach($rifa->items as $item)
<?php $urlImage = $item->imagem ?>


                    <div class="col-sm-4">
                        <div class="image-rifas border-image border-color-<?php echo $cor; ?>">

                            <a href="/items/{{$item->slug}}">
                                <img src="{{ asset('assets/imagem/rifas/'.$urlImage) }}">

                            </a>
                            <span class="title-img-rifas shadow-<?php echo $cor; ?>">  {{$item->name}}</span>
                            <span class="btn valor-rifas">Valor: <small>$
                                   <?php echo number_format($item->valor_rifa, 2, ',', '.')?></small></span>
                        </div>
                    </div>
                @endforeach

            </div>
    @endforeach
    @endisset
@stop
