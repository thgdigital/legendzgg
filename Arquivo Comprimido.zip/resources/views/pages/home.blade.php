@extends('layouts.default')
@section('pageTitle', 'Pagina Inicial')
@section('content')


@stop